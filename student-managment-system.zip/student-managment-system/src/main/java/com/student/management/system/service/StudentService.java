package com.student.management.system.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.management.system.dao.StudentDao;
import com.student.management.system.entity.StudentEntity;

@Service
public class StudentService implements StudentServiceInt {

	@Autowired
	private StudentDao studentDao;

	// List
	public List<StudentEntity> getAllStudent() {
		List<StudentEntity> students = new ArrayList<StudentEntity>();
		studentDao.findAll().forEach(student -> students.add(student));
		return students;
	}

	// getting specfic record
	public StudentEntity getStudentById(int id) {
		return studentDao.findById(id).get();
	}

	public void saveOrUpdate(StudentEntity student) {
		studentDao.save(student);
	}

	// deleting a specific record
	public void delete(int id) {
		studentDao.deleteById(id);
	}

	//update Student
	public StudentEntity updateStudent(StudentEntity student, int id) {
		StudentEntity studentRepo = studentDao.findById(id).get();
		return studentDao.save(student);
	}
}
