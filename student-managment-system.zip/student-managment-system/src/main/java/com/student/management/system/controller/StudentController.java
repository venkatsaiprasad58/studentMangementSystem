package com.student.management.system.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.student.management.system.entity.StudentEntity;
import com.student.management.system.service.StudentService;

@RestController
@RequestMapping("/api")
public class StudentController {

	@Autowired
	StudentService studentService;

	@PostMapping("/student")
	private int saveStudent(@RequestBody StudentEntity student) {
		studentService.saveOrUpdate(student);
		return student.getId();
	}

	@DeleteMapping("/student/{id}")
	private void deleteStudent(@PathVariable("id") int id) {
		studentService.delete(id);
	}

	@GetMapping("/student")
	private List<StudentEntity> getAllStudent() {
		return studentService.getAllStudent();
	}
	
	@PutMapping("/student/{id}")
	private StudentEntity updateStudent(@RequestBody StudentEntity studnet, @PathVariable(value = "id") int id) {
		return studentService.updateStudent(studnet, id);
	}

	
//	@GetMapping("/student")
//	 Page studentPageable(Pageable pageable){
//		return studentDao.findAll(pageable);
//	}
	
//	@GetMapping("/student")
//	public List<StudentEntity> findByPublished(@RequestParam(defaultValue = "") String searchby,
//			@RequestParam(defaultValue = "") String searchfor, @RequestParam(defaultValue = "5") int page,
//			@RequestParam(value = "1") int offSet) {
//		return studentService.fetchFilteredStudentsDataAsList(searchby, searchfor, page, offSet);
//	}
//
}
