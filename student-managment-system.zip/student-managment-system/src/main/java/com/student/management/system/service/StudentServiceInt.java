package com.student.management.system.service;

import com.student.management.system.entity.StudentEntity;

public interface StudentServiceInt {

	// Update operation
	StudentEntity updateStudent(StudentEntity student, int StudentId);

}
