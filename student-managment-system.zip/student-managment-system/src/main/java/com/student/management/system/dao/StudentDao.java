package com.student.management.system.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.student.management.system.entity.StudentEntity;

@Repository
@EnableJpaRepositories
public interface StudentDao extends JpaRepository<StudentEntity, Integer> {



	//List<StudentEntity> findAll(String searchby, String searchfor, int pageSize, int offSet);

}
